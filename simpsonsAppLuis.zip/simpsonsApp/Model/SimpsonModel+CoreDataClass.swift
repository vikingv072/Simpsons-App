//
//  SimpsonModel+CoreDataClass.swift
//  simpsonsApp
//
//  Created by C02PX1DFFVH5 on 12/10/18.
//  Copyright © 2018 C02PX1DFFVH5. All rights reserved.
//
//

import Foundation
import CoreData

@objc(SimpsonModel)
public class SimpsonModel: NSManagedObject {

}
