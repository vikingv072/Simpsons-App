//
//  SimpsonModel+CoreDataProperties.swift
//  simpsonsApp
//
//  Created by C02PX1DFFVH5 on 12/10/18.
//  Copyright © 2018 C02PX1DFFVH5. All rights reserved.
//
//

import Foundation
import CoreData


extension SimpsonModel {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SimpsonModel> {
        return NSFetchRequest<SimpsonModel>(entityName: "SimpsonModel")
    }

    @NSManaged public var imageURL: String?
    @NSManaged public var result: String?
    @NSManaged public var text: String?

}
