//
//  pictureViewController.swift
//  simpsonsApp
//
//  Created by C02PX1DFFVH5 on 11/30/18.
//  Copyright © 2018 C02PX1DFFVH5. All rights reserved.
//

import UIKit

class pictureViewController: UIViewController {

    @IBOutlet weak var collTable: UICollectionView!
    
    private var cellgames = "Simpcell2"
    private var collViewModel : SimpViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupColView()
        self.setupColViewModel()
    }
    
    private func setupColViewModel() {
        self.collViewModel = SimpViewModel()
        self.collViewModel.updateViews = {
            DispatchQueue.main.async {
               
                self.collTable.reloadData()
            }
        }
        self.collViewModel.loadChar()
    }
    
    private func setupColView() {
        self.collTable.delegate = self
        self.collTable.dataSource = self
    }
    
    
    

}

extension pictureViewController : UICollectionViewDelegate , UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.collViewModel.numberOfChar
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellgames, for: indexPath) as! simpCollViewCell
        
        cell.tag = indexPath.row
        cell.configure(with: collViewModel.chars[indexPath.item])
        
        return cell
    }
}

extension pictureViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 95.0, height: 95.0)
    }
    
}
