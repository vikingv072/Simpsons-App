//
//  detailsViewController.swift
//  simpsonsApp
//
//  Created by C02PX1DFFVH5 on 11/30/18.
//  Copyright © 2018 C02PX1DFFVH5. All rights reserved.
//

import UIKit

class detailsViewController: UIViewController {

    @IBOutlet weak var detImage: UIImageView!
    @IBOutlet weak var detLabel: UILabel!
    
    private var detViewModel : SimpViewModel
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.detImage.contentMode = .scaleAspectFit
        self.detLabel.numberOfLines = 0
        self.setupSimpsonViews()
    }
}
    
    func setupSimpsonViews() {
        
        if let image = pokemon.image {
            self.imageView.image = UIImage(data: Data(referencing: image))
        }
        
        self.detLabel.text = detViewModel.chars.
}

